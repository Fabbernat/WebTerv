<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Fiókom</title>
    <meta charset="UTF-8"/>
    <link rel="stylesheet" href="css/Style.css">

</head>

<body>
<div class="topnav">
    <a href="index.php">Főoldal</a>
    <a href="Rendeles_es_foglalas.php">Rendelés, Foglalás</a>
    <a href="Szemelyzet.php">Legénységünk</a>
    <a href="Terkep.php">Térkép</a>
    <a href="Tortenetunk.php">Történetünk</a>
    <a href="Vendegkonyv.php">Vendégkönyv</a>
    <a class="active" href="Bejelentkezes_es_regisztracio.php" style="float:right">Bejelentkezés</a>
</div>
<div class="zoldhatter">
    <iframe style="margin-top: 100px" src="php/Kepfeltoltes.php" width="100%"></iframe>
    <h1>Felhasználói adatok módosítása</h1>
    <form method="post" action="php/connect.php">
        <label for="jelszo">Új jelszó:</label>
        <input type="password" name="jelszo" id="jelszo">
        <br>
        <label for="szuletesi_datum">Új születési dátum:</label>
        <input type="date" name="szuletesi_datum" id="szuletesi_datum">
        <br>
        <label for="bemutatkozas">Új bemutatkozás:</label>
        <textarea name="bemutatkozas" id="bemutatkozas"></textarea>
        <br>
        <input type="submit" value="Mentés">
    </form>
</div>
</body>
<?php
foreach ($_POST as $adat) {
    echo $adat;
}
?>

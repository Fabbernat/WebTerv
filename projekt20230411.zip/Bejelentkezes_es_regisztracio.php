<!doctype html>
<html lang="hu">

<head>
    <meta charset="utf-8">
    <title>Aczélzivatar halászcsárda</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/Style.css">
    <link rel="stylesheet" href="css/Bejelentkezes.css">
    <link rel="icon" type="image/png" href="img/Kormanykerek-350.png">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            $('form').on('submit', function (e) {
                e.preventDefault();
                var form = $(this);
                var formData = form.serialize();
                $.ajax({
                    type: form.attr('method'),
                    url: form.attr('action'),
                    data: formData,
                    success: function (response) {
                        if (response.status === 'success') {
                            alert('Sikeres bejelentkezés vagy regisztráció!');
                            // Itt végrehajthatod az adatok titkosítását és tárolását a PHP tömbben
                        } else {
                            alert('Hibás felhasználónév vagy jelszó, vagy a két jelszó nem egyezik meg!');
                        }
                    }
                });
            });
        });

        function validateForm() {
            var email = document.getElementById("email").value;
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("confirm-password").value;

            if (email === "" || password === "" || confirmPassword === "") {
                alert("Minden mező kitöltése kötelező!");
                return false;
            }

            if (password !== confirmPassword) {
                alert("A két jelszó nem egyezik meg!");
                return false;
            }

            return true;
        }
    </script>
</head>

<body>
<div class="topnav">
    <a href="index.php">Főoldal</a>
    <a href="Rendeles_es_foglalas.php">Rendelés, Foglalás</a>
    <a href="Szemelyzet.php">Legénységünk</a>
    <a href="Terkep.php">Térkép</a>
    <a href="Tortenetunk.php">Történetünk</a>
    <a href="Vendegkonyv.php">Vendégkönyv</a>
    <a class="active" href="Bejelentkezes_es_regisztracio.php" style="float:right">Bejelentkezés</a>
</div>
<iframe class="regisztracio" src="Bejelentkezes.php" width="100%" height="300"></iframe>
<iframe class="regisztracio" src="Regisztracio.php" width="100%" height="300"></iframe>
</body>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['login-submit'])) {
        // Bejelentkezés gombra kattintva végrehajtott műveletek
        $email = $_POST['email'];
        $password = $_POST['password'];

        $password=encryptData($password);
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Store the email and hashed password in your database
        // ...

        // To verify a password during login
        // Retrieve the hashed password from the database based on the email provided by the user
        // ...
        // Verify the password
        if (password_verify($password, $hashedPassword)) {
            // Password is correct, perform login
            // ...
        } else {
            // Password is incorrect, show error message
            // ...
        }
    }

    if (isset($_POST['register-submit'])) {
        // Regisztráció gombra kattintva végrehajtott műveletek
        $fullName = $_POST['full-name'];
        $email = $_POST['email'];
        $phoneNumber = $_POST['phone-number'];
        $address = $_POST['address'];
        $password = $_POST['password'];

        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Store the user data and hashed password in your database
        // ...
    }
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['login-submit'])) {
        // Bejelentkezés gombra kattintva végrehajtott műveletek
        $email = encryptData($_POST['email']);
        $password = encryptData($_POST['password']);
        // Az adatokat tárolhatod egy tömbben vagy adatbázisban, ahol titkosítva vannak eltárolva
        $user = array(
            'email' => $email,
            'password' => $password
        );
        // További műveletek...
    } elseif (isset($_POST['register-submit'])) {
        // Regisztráció gombra kattintva végrehajtott műveletek
        $fullName = encryptData($_POST['full-name']);
        $email = encryptData($_POST['email']);
        $phoneNumber = encryptData($_POST['phone-number']);
        $address = encryptData($_POST['address']);
        $password = encryptData($_POST['password']);
        // Az adatokat tárolhatod egy tömbben vagy adatbázisban, ahol titkosítva vannak eltárolva
        $user = array(
            'fullName' => $fullName,
            'email' => $email,
            'phoneNumber' => $phoneNumber,
            'address' => $address,
            'password' => $password
        );
        // További műveletek...
    }
}

function encryptData($data)
{
    // Itt végezheted el az adatok titkosítását, például használhatsz beépített PHP függvényeket vagy saját titkosítási algoritmust
    // Ebben a példában az adatokat md5 hash függvénnyel titkosítjuk
    $encryptedData = md5($data);
    return $encryptedData;
}

?>

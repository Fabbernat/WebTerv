<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>Aczélzivatar halászcsárda</title>
  <link rel="stylesheet" href="css/Style.css">
</head>
<body>
<div class="kepAVegen" style="background-color: #cdba96">
  <img src="img/asztalfoglalás.jpg" alt="asztalfoglalás">
  <h1>Melyik asztalt szeretnéd lefoglalni?</h1>
  <form>
    <label for="elsoopcio">Az egész hely lefoglalása:</label>
    <input type="radio" checked id="elsoopcio" name="hobby-2" value="cooking"><br>
    <h1>VAGY</h1>
    <label for="masodikopcio">Egyéni kiválasztás:</label>
    <input type="radio" checked id="masodikopcio" name="hobby-2" value="cooking"><br>
    <label for="asztal1">1.</label>
    <input type="checkbox" id="asztal1" name="asztal" value="asztal">
    <label for="asztal2">2.</label>
    <input type="checkbox" id="asztal2" name="asztal" value="asztal">
    <label for="asztal3">3.</label>
    <input type="checkbox" id="asztal3" name="asztal" value="asztal">
    <label for="asztal4">4.</label>
    <input type="checkbox" id="asztal4" name="asztal" value="asztal">
    <label for="asztal5">5.</label>
    <input type="checkbox" id="asztal5" name="asztal" value="asztal">
    <label for="asztal6">6.</label>
    <input type="checkbox" id="asztal6" name="asztal" value="asztal">
    <label for="asztal7">7.</label>
    <input type="checkbox" id="asztal7" name="asztal" value="asztal">
    <label for="asztal8">8.</label>
    <input type="checkbox" id="asztal8" name="asztal" value="asztal"> <br>
    <label for="asztal9">9.</label>
    <input type="checkbox" id="asztal9" name="asztal" value="asztal">
    <label for="asztal10">10.</label>
    <input type="checkbox" id="asztal10" name="asztal" value="asztal">
    <label for="asztal11">11.</label>
    <input type="checkbox" id="asztal11" name="asztal" value="asztal">
    <label for="asztal12">12.</label>
    <input type="checkbox" id="asztal12" name="asztal" value="asztal">
    <label for="asztal13">13.</label>
    <input type="checkbox" id="asztal13" name="asztal" value="asztal">
    <label for="asztal14">14.</label>
    <input type="checkbox" id="asztal14" name="asztal" value="asztal">
    <label for="asztal15">15.</label>
    <input type="checkbox" id="asztal15" name="asztal" value="asztal">
    <label for="asztal16">16.</label>
    <input type="checkbox" id="asztal16" name="asztal" value="asztal"> <br>
  </form>
</div>

<div class="alsoSor">
  <h6 class="csakfont" style="font-size: medium">Elérhetőség:</h6>
  <pre style="font-size: large">
  E-mail: h259147@stud.u-szeged.hu
  Telefon: +36308375338
  Facebook:
  Instagram:
  Twitter:
  Github:
  Discord:
  Coospace:
  </pre>
  Fabbernat & Magyarkebab©
</div>

</body>
</html>
